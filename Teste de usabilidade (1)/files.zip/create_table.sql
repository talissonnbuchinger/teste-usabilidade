-- Cole isso no SQL Editor do seu projeto Supabase
-- (Dashboard → SQL Editor → New query)

create table if not exists usability_sessions (
  id            uuid primary key default gen_random_uuid(),
  created_at    timestamptz default now(),
  produto       text,
  tipo          text,
  objetivo      text,
  perfil        text,
  participante  text,
  moderador     text,
  tarefas       jsonb,
  atrito        text,
  deleite       text,
  observacoes   text
);

-- Permite leitura e escrita pública (necessário para o app funcionar sem login)
alter table usability_sessions enable row level security;

create policy "Leitura pública" on usability_sessions
  for select using (true);

create policy "Escrita pública" on usability_sessions
  for insert with check (true);
